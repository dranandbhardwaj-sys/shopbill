# ShopBill — Smart Billing for Small Shops

A mobile-first, installable Progressive Web App (PWA) prototype for small Indian retailers. Built with plain HTML, CSS, and JavaScript — no framework or build step required.

## Features

- Single-page dashboard with overview, invoice, products, customer ledger, reports, settings, and pricing views
- Invoice creation with line items and per-item GST calculation
- Invoice history and downloadable invoice text files
- Product catalog, stock counts, and low-stock indicators
- Customer balances and payment recording
- Shop profile and GSTIN settings
- JSON data export and demo reset
- LocalStorage persistence on the current browser/device
- PWA manifest, app icons, and service worker shell caching for offline reopening
- Responsive mobile and desktop layouts

## Run locally

Requires Python 3.

```bash
./start.sh
```

Then open <http://localhost:8080> in your browser. Set another port if needed:

```bash
PORT=3000 ./start.sh
```

You can also run `python3 -m http.server 8080` from this directory.

> PWA installation and service-worker offline caching require `localhost` or HTTPS. Opening `index.html` directly with `file://` supports the UI, but not service-worker installation.

## Project structure

```text
shopbill/
├── index.html              # Main HTML and SPA shell
├── css/
│   └── app.css             # Responsive styles
├── js/
│   └── app.js              # Application logic and local persistence
├── icons/
│   ├── icon-192.png        # PWA icon
│   └── icon-512.png        # PWA icon
├── manifest.json           # PWA manifest
├── sw.js                   # Service worker / offline app shell
├── start.sh                # Local server launcher
└── README.md               # Documentation
```

## Data and production notes

This prototype stores shop data in the browser's `localStorage`. It is not yet a multi-user cloud SaaS: data is device/browser-specific and can be cleared by the user or browser. The plan selector is a demo only; no real payment is charged.

Before production use, connect secure authentication, a tenant-aware backend/database, server-side invoice numbering, verified GST/tax rules, PDF generation, payment provider webhooks, backups, access controls, and privacy/terms pages. Validate invoice format and tax treatment with a qualified accountant before issuing legally relied-upon GST invoices.
