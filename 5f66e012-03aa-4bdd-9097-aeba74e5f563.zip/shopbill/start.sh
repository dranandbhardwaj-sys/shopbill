#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8080}"
if command -v python3 >/dev/null 2>&1; then
  echo "ShopBill running at http://localhost:${PORT} (Ctrl+C to stop)"
  python3 -m http.server "$PORT"
else
  echo "Python 3 is required to run the local server." >&2
  exit 1
fi
